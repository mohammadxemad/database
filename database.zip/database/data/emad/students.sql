CREATE TABLE students (
    `student_id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50)
);

INSERT INTO students (`student_id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50)) VALUES
'student12' 'mohamed',
'student22' 'ahmed'
