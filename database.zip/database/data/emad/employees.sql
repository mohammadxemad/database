CREATE TABLE employees (
    eg123 Name age address empid int name varchar age int address varchar `emp_id` VARCHAR(20) PRIMARY KEY `name` var `age` int `address` var
);

INSERT INTO employees (eg123 Name age address empid int name varchar age int address varchar `emp_id` VARCHAR(20) PRIMARY KEY `name` var `age` int `address` var) VALUES
'em12' 'mohamed' '20' 'maadi',
'em13' 'ahmed' '21' 'giza'
