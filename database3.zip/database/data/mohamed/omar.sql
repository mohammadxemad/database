CREATE TABLE omar (
    `student_id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `num` VARCHAR(20) PRIMARY KEY `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `age` INT
);

INSERT INTO omar (`student_id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `num` VARCHAR(20) PRIMARY KEY `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `id` VARCHAR(20) PRIMARY KEY `name` VARCHAR(50) `age` INT) VALUES
  (value1, value2, value3),
  (value4, value5, value6);
'10' 'mohamed' '10',
'3' '123' 'egp',
'egp' 'ahmed' 'asd',
